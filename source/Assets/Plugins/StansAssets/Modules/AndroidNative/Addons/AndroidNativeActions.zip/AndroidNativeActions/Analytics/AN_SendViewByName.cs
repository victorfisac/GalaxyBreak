﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SendViewByName : FsmStateAction {

		public FsmString appScreenName;

		public override void OnEnter() {
			if (appScreenName != null) {
				AndroidGoogleAnalytics.Instance.SendView (appScreenName.Value);
			}

			Finish ();
		}

	}
}
