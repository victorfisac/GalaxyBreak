﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterUserLookUpRequest : FsmStateAction {
			
		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmString user_id;

		public FsmString id;
		public FsmString name;
		public FsmString screen_name;
		public FsmInt friends_count;
		public FsmString profile_image_url;
		public FsmString profile_image_url_https;
		
		public override void OnEnter() {	
			TW_UsersLookUpRequest r =  TW_UsersLookUpRequest.Create();
			r.ActionComplete += OnLookUpRequestComplete;
			if (user_id.Value.Length > 0) {
				r.AddParam("user_id", user_id.Value);
			}
			r.Send();
		}
		
		private void OnLookUpRequestComplete(TW_APIRequstResult result) {
						
			if(result.IsSucceeded) {
				this.id.Value = result.users[0].id;
				this.name.Value = result.users[0].name;
				this.screen_name.Value = result.users[0].screen_name;
				this.friends_count.Value = result.users[0].friends_count;
				this.profile_image_url.Value = result.users[0].profile_image_url;
				this.profile_image_url_https.Value = result.users[0].profile_image_url_https;

				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
