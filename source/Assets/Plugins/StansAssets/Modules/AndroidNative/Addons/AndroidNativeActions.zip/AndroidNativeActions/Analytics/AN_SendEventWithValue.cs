﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SendEventWithValue : FsmStateAction {

		public FsmString category;
		public FsmString action;
		public FsmString label;
		public FsmInt value;
		public FsmString key;
		public FsmString val;

		public override void OnEnter() {
			if (value != null) {
				AndroidGoogleAnalytics.Instance.SendEvent (category.Value, action.Value, label.Value, (long)value.Value, key.Value, val.Value);
			} else {
				AndroidGoogleAnalytics.Instance.SendEvent (category.Value, action.Value, label.Value, key.Value, val.Value);
			}

			Finish ();	
		}

	}
}
