﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SendView : FsmStateAction {

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.SendView ();

			Finish ();
		}

	}
}
