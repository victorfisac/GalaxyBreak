﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SetDryRun : FsmStateAction {

		public FsmBool mode;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.SetDryRun (mode.Value);

			Finish ();
		}
	}
}
