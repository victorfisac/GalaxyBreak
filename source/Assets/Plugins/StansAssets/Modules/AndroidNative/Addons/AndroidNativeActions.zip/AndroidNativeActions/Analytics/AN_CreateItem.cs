﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_CreateItem : FsmStateAction {

		public FsmString transactionId;
		public FsmString name;
		public FsmString sku;
		public FsmString category;
		public FsmFloat price;
		public FsmInt quantity;
		public FsmString currencyCode;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.CreateItem (transactionId.Value, name.Value, sku.Value, category.Value, price.Value, quantity.Value, currencyCode.Value);

			Finish ();
		}
	}
}
