﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Billing")]
	public class AN_RetriveProductInfo : FsmStateAction {

		public FsmString ProductSKU  = "";

		public FsmString localizedPrice;
		public FsmFloat price;	
		public FsmString title;
		public FsmString description;
		public FsmInt priceAmountMicros;
		public FsmString priceCurrencyCode;

		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public override void OnEnter() {
			#if UNITY_EDITOR
				Fsm.Event(successEvent);
				Finish();
			#endif

	   		#if !UNITY_EDITOR
				InitAndroidInventoryTask iTask = InitAndroidInventoryTask.Create();
				iTask.ActionComplete += OnInvComplete;
				iTask.ActionFailed += OnInvFailed;
				iTask.Run();
			#endif			
		}

		private void OnInvComplete() {
			if(AndroidInAppPurchaseManager.Client.Inventory.GetProductDetails(ProductSKU.Value) != null) {
				OnSuccess();
			} else {
				OnFailed();
			}
		}

		private void OnInvFailed() {
			OnFailed();
		}

		private void OnSuccess() {
			GoogleProductTemplate tpl =  AndroidInAppPurchaseManager.Client.Inventory.GetProductDetails(ProductSKU.Value);

			price.Value = tpl.Price;
			localizedPrice.Value = tpl.LocalizedPrice;
			title.Value = tpl.Title;
			description.Value = tpl.Description;
			priceAmountMicros.Value = (int)tpl.PriceAmountMicros;
			priceCurrencyCode.Value = tpl.PriceCurrencyCode;

			Fsm.Event(successEvent);
			Finish();
		}

		private void OnFailed() {
			Fsm.Event(failEvent);
			Finish();
		}
	}
}
